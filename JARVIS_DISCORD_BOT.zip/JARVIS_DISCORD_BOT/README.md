# J.A.R.V.I.S Discord Bot

A beginner-friendly Discord bot written in Python with slash commands, moderation tools, utility commands, and fun commands.

## Features

### Moderation
- `/clear amount` — delete 1–100 recent messages.
- `/kick member reason` — kick a member.
- `/ban member reason` — ban a member.
- `/timeout member minutes reason` — timeout a member for up to 7 days.

### Utility
- `/help` — show the command guide.
- `/ping` — show latency.
- `/poll question` — create a 👍 / 👎 poll.
- `/announce channel title message` — post an embed announcement.
- `/serverinfo` — show server details.
- `/userinfo member` — show member details.

### Fun
- `/dice` — roll a six-sided die.
- `/coinflip` — flip a coin.
- `/8ball question` — ask the magic 8-ball.

## Requirements

- Windows, macOS, or Linux
- Python 3.10 or newer
- A Discord account and a server where you can add applications

## 1. Create the Discord application

1. Open the [Discord Developer Portal](https://discord.com/developers/applications).
2. Select **New Application** and name it `J.A.R.V.I.S`.
3. Open **Bot** and create/reset the bot token.
4. Copy the token. Keep it private; never upload it to GitHub or share it.
5. Open **OAuth2 → URL Generator**.
6. Select scopes: `bot` and `applications.commands`.
7. Select bot permissions needed by the commands:
   - View Channels
   - Send Messages
   - Embed Links
   - Read Message History
   - Manage Messages
   - Kick Members
   - Ban Members
   - Moderate Members
8. Open the generated URL and add the bot to your server.

Discord role hierarchy still applies: move the bot's role above the members it must moderate.

## 2. Install the project

Open PowerShell in this project folder:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
```

If PowerShell blocks activation, you can skip activation and run:

```powershell
py -m pip install -r requirements.txt
```

## 3. Configure the token

Copy the example environment file:

```powershell
Copy-Item .env.example .env
```

Open `.env` and paste your bot token:

```env
DISCORD_TOKEN=PASTE_YOUR_BOT_TOKEN_HERE
GUILD_ID=
```

Optional: put your server ID in `GUILD_ID` to sync slash commands to that server quickly while developing. To copy a server ID, enable Developer Mode in Discord, right-click the server, and choose **Copy Server ID**. Leave it blank to sync globally.

## 4. Start the bot

```powershell
py bot.py
```

Keep the terminal open while you want the bot online. In Discord, try `/help` or `/ping`.

## Troubleshooting

- **`DISCORD_TOKEN is missing`**: check that `.env` is in the same folder as `bot.py` and that the variable is named `DISCORD_TOKEN`.
- **Bot is online but slash commands are missing**: wait a little for global sync, or set `GUILD_ID` to your test server ID and restart the bot.
- **`Missing Permissions`**: grant the bot the required permissions and check that its role is above the target member's role.
- **`PrivilegedIntentsRequired`**: this project requests the Server Members Intent for member-related features. In Developer Portal → Bot → Privileged Gateway Intents, enable **Server Members Intent**.
- **`ModuleNotFoundError: discord`**: install dependencies with `py -m pip install -r requirements.txt`.

## Security

- Never commit `.env` or expose your bot token.
- If the token is leaked, reset it immediately in the Developer Portal.
- Do not give the bot Administrator permission unless you genuinely need it.
- Use moderation commands responsibly.

## Project files

```text
JARVIS_DISCORD_BOT/
├── bot.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Notes

This version uses Discord slash commands and does not need the Message Content Intent. The bot must be online for commands to work. AI chat, music, welcome messages, and database-backed settings are not included in this starter version yet.
