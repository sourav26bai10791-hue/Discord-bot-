"""
J.A.R.V.I.S Discord Bot
A beginner-friendly Discord bot using discord.py 2.x.

Run:
    py -m pip install -r requirements.txt
    copy .env.example .env   (Windows PowerShell: Copy-Item .env.example .env)
    # Add your Discord bot token to .env
    py bot.py
"""

import logging
import os
import random
from datetime import timedelta

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = os.getenv("GUILD_ID")  # Optional: faster slash-command sync to one server

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("JARVIS")


class JarvisBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True
        intents.message_content = False
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        if GUILD_ID:
            guild = discord.Object(id=int(GUILD_ID))
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            logger.info("Synced %s command(s) to guild %s", len(synced), GUILD_ID)
        else:
            synced = await self.tree.sync()
            logger.info("Synced %s global command(s)", len(synced))

    async def on_ready(self):
        logger.info("Logged in as %s (ID: %s)", self.user, self.user.id)
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.listening,
                name="your commands | /help",
            )
        )


bot = JarvisBot()


def make_embed(title: str, description: str, color: discord.Color = discord.Color.blurple()):
    return discord.Embed(title=title, description=description, color=color)


@bot.tree.command(name="help", description="Show J.A.R.V.I.S commands.")
async def help_command(interaction: discord.Interaction):
    embed = make_embed(
        "J.A.R.V.I.S | Command Guide",
        "**Moderation**\n"
        "`/clear` — Delete recent messages\n"
        "`/kick` — Kick a member\n"
        "`/ban` — Ban a member\n"
        "`/timeout` — Temporarily timeout a member\n\n"
        "**Utility**\n"
        "`/poll` — Create a yes/no poll\n"
        "`/announce` — Send an announcement\n"
        "`/serverinfo` — Show server information\n"
        "`/userinfo` — Show information about a member\n\n"
        "**Fun**\n"
        "`/dice` — Roll a die\n"
        "`/coinflip` — Flip a coin\n"
        "`/8ball` — Ask the magic 8-ball"
    )
    embed.set_footer(text="J.A.R.V.I.S • At your service")
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(name="ping", description="Check the bot's response latency.")
async def ping(interaction: discord.Interaction):
    ms = round(bot.latency * 1000)
    await interaction.response.send_message(f"**Pong!** `{ms} ms`")


@bot.tree.command(name="dice", description="Roll a six-sided die.")
async def dice(interaction: discord.Interaction):
    result = random.randint(1, 6)
    await interaction.response.send_message(f"🎲 You rolled **{result}**!")


@bot.tree.command(name="coinflip", description="Flip a coin.")
async def coinflip(interaction: discord.Interaction):
    await interaction.response.send_message(f"🪙 **{random.choice(['Heads', 'Tails'])}!**")


@bot.tree.command(name="8ball", description="Ask the magic 8-ball a question.")
@app_commands.describe(question="What do you want to ask?")
async def eight_ball(interaction: discord.Interaction, question: str):
    answers = [
        "Absolutely.", "It is certain.", "Without a doubt.",
        "Probably.", "Ask again later.", "The outlook is unclear.",
        "I wouldn't count on it.", "Very unlikely.",
    ]
    await interaction.response.send_message(
        f"🎱 **Question:** {discord.utils.escape_markdown(question)}\n**J.A.R.V.I.S:** {random.choice(answers)}"
    )


@bot.tree.command(name="poll", description="Create a yes/no poll.")
@app_commands.describe(question="The poll question")
async def poll(interaction: discord.Interaction, question: str):
    embed = make_embed("📊 Community Poll", question)
    embed.set_footer(text=f"Poll by {interaction.user.display_name}")
    await interaction.response.send_message(embed=embed)
    message = await interaction.original_response()
    await message.add_reaction("👍")
    await message.add_reaction("👎")


@bot.tree.command(name="serverinfo", description="Display information about this server.")
async def serverinfo(interaction: discord.Interaction):
    guild = interaction.guild
    if guild is None:
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return
    embed = make_embed(f"🏠 {guild.name}", "Server information")
    embed.add_field(name="Members", value=str(guild.member_count or "Unknown"))
    embed.add_field(name="Owner ID", value=str(guild.owner_id))
    embed.add_field(name="Created", value=discord.utils.format_dt(guild.created_at, style="D"))
    embed.add_field(name="Text channels", value=str(len(guild.text_channels)))
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="userinfo", description="Display information about a member.")
@app_commands.describe(member="The member to inspect (defaults to you)")
async def userinfo(interaction: discord.Interaction, member: discord.Member | None = None):
    member = member or interaction.user
    embed = make_embed(f"👤 {member.display_name}", f"**Username:** {member}\n**User ID:** `{member.id}`")
    embed.add_field(name="Joined server", value=discord.utils.format_dt(member.joined_at, style="D") if member.joined_at else "Unknown")
    embed.add_field(name="Account created", value=discord.utils.format_dt(member.created_at, style="D"))
    embed.add_field(name="Top role", value=member.top_role.mention if member.top_role else "None")
    embed.set_thumbnail(url=member.display_avatar.url)
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="clear", description="Delete a number of recent messages.")
@app_commands.checks.has_permissions(manage_messages=True)
@app_commands.describe(amount="Number of messages to delete (1–100)")
async def clear(interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]):
    if not isinstance(interaction.channel, (discord.TextChannel, discord.Thread)):
        await interaction.response.send_message("This command needs a text channel.", ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    deleted = await interaction.channel.purge(limit=amount)
    await interaction.followup.send(f"🧹 Deleted **{len(deleted)}** message(s).", ephemeral=True)


@bot.tree.command(name="kick", description="Kick a member from the server.")
@app_commands.checks.has_permissions(kick_members=True)
@app_commands.describe(member="Member to kick", reason="Reason for the kick")
async def kick(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    if member.id == interaction.user.id:
        await interaction.response.send_message("You cannot kick yourself.", ephemeral=True)
        return
    if member.top_role >= interaction.user.top_role and interaction.guild.owner_id != interaction.user.id:
        await interaction.response.send_message("That member has an equal or higher role than you.", ephemeral=True)
        return
    await member.kick(reason=f"{reason} | By {interaction.user}")
    await interaction.response.send_message(f"👢 **{member}** was kicked.\nReason: {reason}")


@bot.tree.command(name="ban", description="Ban a member from the server.")
@app_commands.checks.has_permissions(ban_members=True)
@app_commands.describe(member="Member to ban", reason="Reason for the ban")
async def ban(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    if member.id == interaction.user.id:
        await interaction.response.send_message("You cannot ban yourself.", ephemeral=True)
        return
    if member.top_role >= interaction.user.top_role and interaction.guild.owner_id != interaction.user.id:
        await interaction.response.send_message("That member has an equal or higher role than you.", ephemeral=True)
        return
    await member.ban(reason=f"{reason} | By {interaction.user}")
    await interaction.response.send_message(f"🔨 **{member}** was banned.\nReason: {reason}")


@bot.tree.command(name="timeout", description="Temporarily timeout a member.")
@app_commands.checks.has_permissions(moderate_members=True)
@app_commands.describe(member="Member to timeout", minutes="Duration in minutes (1–10080)", reason="Reason")
async def timeout(
    interaction: discord.Interaction,
    member: discord.Member,
    minutes: app_commands.Range[int, 1, 10080],
    reason: str = "No reason provided",
):
    if member.id == interaction.user.id:
        await interaction.response.send_message("You cannot timeout yourself.", ephemeral=True)
        return
    if member.top_role >= interaction.user.top_role and interaction.guild.owner_id != interaction.user.id:
        await interaction.response.send_message("That member has an equal or higher role than you.", ephemeral=True)
        return
    await member.timeout(timedelta(minutes=minutes), reason=f"{reason} | By {interaction.user}")
    await interaction.response.send_message(f"⏳ **{member}** was timed out for **{minutes} minute(s)**.\nReason: {reason}")


@bot.tree.command(name="announce", description="Send an announcement to a channel.")
@app_commands.checks.has_permissions(manage_guild=True)
@app_commands.describe(channel="Where to post", title="Announcement title", message="Announcement text")
async def announce(
    interaction: discord.Interaction,
    channel: discord.TextChannel,
    title: str,
    message: str,
):
    embed = make_embed(title, message, discord.Color.gold())
    embed.set_footer(text=f"Announcement by {interaction.user.display_name}")
    await channel.send(embed=embed)
    await interaction.response.send_message(f"📢 Announcement sent to {channel.mention}.", ephemeral=True)


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        message = "You don't have the Discord permissions required for that command."
    elif isinstance(error, app_commands.BotMissingPermissions):
        message = "I don't have the required permissions. Check my role and channel permissions."
    elif isinstance(error, app_commands.CommandOnCooldown):
        message = "That command is on cooldown. Try again shortly."
    else:
        logger.error("Command error: %s", error, exc_info=error)
        message = "Something went wrong while running that command."

    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit(
            "DISCORD_TOKEN is missing. Copy .env.example to .env and add your bot token."
        )
    bot.run(TOKEN)
